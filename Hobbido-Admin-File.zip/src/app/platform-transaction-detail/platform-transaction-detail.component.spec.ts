import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlatformTransactionDetailComponent } from './platform-transaction-detail.component';

describe('PlatformTransactionDetailComponent', () => {
  let component: PlatformTransactionDetailComponent;
  let fixture: ComponentFixture<PlatformTransactionDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlatformTransactionDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlatformTransactionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
