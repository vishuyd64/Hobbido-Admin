import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-platform-transaction-detail',
  templateUrl: './platform-transaction-detail.component.html',
  styleUrls: ['./platform-transaction-detail.component.scss']
})
export class PlatformTransactionDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
