import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    // $(".Toggle").click(function () {
    //   $(".Header").addClass("HeaderPush");
    //   $(".SidenavArea").addClass("SidePush");
    //   $(".MainMargin").css({ "margin-left": "60px", "width": "calc(100% - 60px)" });
    // });
    // $(".CloseToggle").click(function () {
    //   $(".Header").removeClass("HeaderPush");
    //   $(".SidenavArea").removeClass("SidePush");
    //   $(".MainMargin").css({ "margin-left": "225px", "width": "calc(100% - 225px)" });
    // });


  }

}
