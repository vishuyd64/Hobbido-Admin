import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostManagementDetailComponent } from './host-management-detail.component';

describe('HostManagementDetailComponent', () => {
  let component: HostManagementDetailComponent;
  let fixture: ComponentFixture<HostManagementDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostManagementDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostManagementDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
