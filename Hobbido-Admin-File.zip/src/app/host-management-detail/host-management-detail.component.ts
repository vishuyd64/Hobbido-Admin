import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-host-management-detail',
  templateUrl: './host-management-detail.component.html',
  styleUrls: ['./host-management-detail.component.scss']
})
export class HostManagementDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function() {
      $('.static_content_menu li a').click(function() {
          var $this = $(this).attr('data-tag');
          $('.static_content_menu li a').parent('li').removeClass('active');
          $(this).parent('li').addClass('active');
          $('.content').hide().removeClass('show');
          $('#' + $this).show();
      });
  })
  }

}
