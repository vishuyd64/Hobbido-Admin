import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-admin-management',
  templateUrl: './sub-admin-management.component.html',
  styleUrls: ['./sub-admin-management.component.scss']
})
export class SubAdminManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
