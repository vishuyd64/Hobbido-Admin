import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
        // block and unblock user
   
  
  
  }

}
