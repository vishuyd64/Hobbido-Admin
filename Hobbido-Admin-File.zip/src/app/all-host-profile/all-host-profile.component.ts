import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-all-host-profile',
  templateUrl: './all-host-profile.component.html',
  styleUrls: ['./all-host-profile.component.scss']
})
export class AllHostProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function() {
      $('.static_content_menu li a').click(function() {
          var $this = $(this).attr('data-tag');
          $('.static_content_menu li a').parent('li').removeClass('active');
          $(this).parent('li').addClass('active');
          $('.content').hide().removeClass('show');
          $('#' + $this).show();
      });
  })
  }

}
