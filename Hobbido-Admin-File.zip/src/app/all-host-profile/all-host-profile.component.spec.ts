import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllHostProfileComponent } from './all-host-profile.component';

describe('AllHostProfileComponent', () => {
  let component: AllHostProfileComponent;
  let fixture: ComponentFixture<AllHostProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllHostProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllHostProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
