import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featuring',
  templateUrl: './featuring.component.html',
  styleUrls: ['./featuring.component.scss']
})
export class FeaturingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
