import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostPendingComponent } from './host-pending.component';

describe('HostPendingComponent', () => {
  let component: HostPendingComponent;
  let fixture: ComponentFixture<HostPendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostPendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
