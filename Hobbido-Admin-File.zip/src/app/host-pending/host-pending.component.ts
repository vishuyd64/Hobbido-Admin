import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-host-pending',
  templateUrl: './host-pending.component.html',
  styleUrls: ['./host-pending.component.scss']
})
export class HostPendingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
