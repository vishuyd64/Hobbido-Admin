import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-static-content',
  templateUrl: './static-content.component.html',
  styleUrls: ['./static-content.component.scss']
})
export class StaticContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    //faq start
$(document).ready(function () {
  $(".set > a").on("click", function () {
      if ($(this).hasClass("active")) {
          $(this).removeClass("active");
          $(this).siblings(".content").slideUp(500);
          $(".set > a i").removeClass("fa-chevron-down").addClass("fa-chevron-right");
      } else {
          $(".set > a i").removeClass("fa-chevron-down").addClass("fa-chevron-right");
          $(this).find("i").removeClass("fa-chevron-right").addClass("fa-chevron-down");

          $(".set > a").removeClass("active");
          $(this).addClass("active");
          $(".content").slideUp(500);
          $(this).siblings(".content").slideDown(500);
      }
  });
});
//faq end
  }

}
