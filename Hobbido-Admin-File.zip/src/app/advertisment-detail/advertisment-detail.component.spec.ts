import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertismentDetailComponent } from './advertisment-detail.component';

describe('AdvertismentDetailComponent', () => {
  let component: AdvertismentDetailComponent;
  let fixture: ComponentFixture<AdvertismentDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvertismentDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvertismentDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
