import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertisment-detail',
  templateUrl: './advertisment-detail.component.html',
  styleUrls: ['./advertisment-detail.component.scss']
})
export class AdvertismentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
