import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-add-promocode',
  templateUrl: './add-promocode.component.html',
  styleUrls: ['./add-promocode.component.scss']
})
export class AddPromocodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('.selectAll_checkbox').on('click',function() {
      if($(this).is(':checked')) {
          $(this).parents('li').nextAll('li').find('input').prop('checked',true);
      }else {
          $(this).parents('li').nextAll('li').find('input').prop('checked',false);
      }
  });
  }

}
