import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promocode-detail',
  templateUrl: './promocode-detail.component.html',
  styleUrls: ['./promocode-detail.component.scss']
})
export class PromocodeDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
