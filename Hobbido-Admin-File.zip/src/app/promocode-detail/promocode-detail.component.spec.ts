import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromocodeDetailComponent } from './promocode-detail.component';

describe('PromocodeDetailComponent', () => {
  let component: PromocodeDetailComponent;
  let fixture: ComponentFixture<PromocodeDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromocodeDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromocodeDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
