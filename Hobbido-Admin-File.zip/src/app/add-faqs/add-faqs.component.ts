import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-faqs',
  templateUrl: './add-faqs.component.html',
  styleUrls: ['./add-faqs.component.scss']
})
export class AddFaqsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
