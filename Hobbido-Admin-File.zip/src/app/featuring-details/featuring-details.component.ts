import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featuring-details',
  templateUrl: './featuring-details.component.html',
  styleUrls: ['./featuring-details.component.scss']
})
export class FeaturingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
