import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeaturingDetailsComponent } from './featuring-details.component';

describe('FeaturingDetailsComponent', () => {
  let component: FeaturingDetailsComponent;
  let fixture: ComponentFixture<FeaturingDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeaturingDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeaturingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
