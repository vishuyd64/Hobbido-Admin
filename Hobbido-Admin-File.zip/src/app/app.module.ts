import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ForgotComponent } from './forgot/forgot.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { ProfileComponent } from './profile/profile.component';
import { PasswordComponent } from './password/password.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { HostManagementComponent } from './host-management/host-management.component';
import { ActivityManagementComponent } from './activity-management/activity-management.component';
import { BookingManagementComponent } from './booking-management/booking-management.component';
import { TransactionManagementComponent } from './transaction-management/transaction-management.component';
import { VoucherManagementComponent } from './voucher-management/voucher-management.component';
import { PromocodeManagementComponent } from './promocode-management/promocode-management.component';
import { InvoiceManagementComponent } from './invoice-management/invoice-management.component';
import { SubAdminManagementComponent } from './sub-admin-management/sub-admin-management.component';
import { AdvertismentManagementComponent } from './advertisment-management/advertisment-management.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { StaticContentComponent } from './static-content/static-content.component';
import { UserManagementDetailComponent } from './user-management-detail/user-management-detail.component';
import { HostManagementDetailComponent } from './host-management-detail/host-management-detail.component';
import { SubAdminManagementDetailComponent } from './sub-admin-management-detail/sub-admin-management-detail.component';
import { NotificationComponent } from './notification/notification.component';
import { PushNotificationComponent } from './push-notification/push-notification.component';
import { AddInvoiceComponent } from './add-invoice/add-invoice.component';
import { AddPromocodeComponent } from './add-promocode/add-promocode.component';
import { TransactionDetailComponent } from './transaction-detail/transaction-detail.component';
import { ActivityDetailComponent } from './activity-detail/activity-detail.component';
import { AuditLogComponent } from './audit-log/audit-log.component';
import { ReportManagementComponent } from './report-management/report-management.component';
import { HostPendingComponent } from './host-pending/host-pending.component';
import { HostRejectedComponent } from './host-rejected/host-rejected.component';
import { AddSubAdminComponent } from './add-sub-admin/add-sub-admin.component';
import { BookingDetailComponent } from './booking-detail/booking-detail.component';
import { CategoryComponent } from './category/category.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { PaymentManagementComponent } from './payment-management/payment-management.component';
import { AddFaqsComponent } from './add-faqs/add-faqs.component';
import { EditFaqsComponent } from './edit-faqs/edit-faqs.component';
import { AllHostProfileComponent } from './all-host-profile/all-host-profile.component';
import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { AdvertismentDetailComponent } from './advertisment-detail/advertisment-detail.component';
import { PlatformTransactionDetailComponent } from './platform-transaction-detail/platform-transaction-detail.component';
import { PromocodeDetailComponent } from './promocode-detail/promocode-detail.component';
import { EditpromocodeComponent } from './editpromocode/editpromocode.component';
import { ComposeNewComponent } from './compose-new/compose-new.component';
import { VoucherDetailComponent } from './voucher-detail/voucher-detail.component';
import { EditVoucherComponent } from './edit-voucher/edit-voucher.component';
import { AddVoucherComponent } from './add-voucher/add-voucher.component';
import { InvoiceDetailComponent } from './invoice-detail/invoice-detail.component';
import { PushNotificationDetailComponent } from './push-notification-detail/push-notification-detail.component';
import { DefualtManagementComponent } from './defualt-management/defualt-management.component';
import { ContentReportComponent } from './content-report/content-report.component';
import { EditAdminUserComponent } from './edit-admin-user/edit-admin-user.component';
import { CreateSubCategoryComponent } from './create-sub-category/create-sub-category.component';
import { ProgrmDetailsComponent } from './progrm-details/progrm-details.component';
import { FeaturingComponent } from './featuring/featuring.component';
import { HostRankComponent } from './host-rank/host-rank.component';
import { FeaturingDetailsComponent } from './featuring-details/featuring-details.component';
import { FeaturingAddComponent } from './featuring-add/featuring-add.component';
import { ActivityGroupComponent } from './activity-group/activity-group.component';
import { ActivityGroupDetailsComponent } from './activity-group-details/activity-group-details.component';
import { AddActivityGroupComponent } from './add-activity-group/add-activity-group.component';
import { EditActivityGroupComponent } from './edit-activity-group/edit-activity-group.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotComponent,
    DashboardComponent,
    HeaderComponent,
    SidenavComponent,
    ProfileComponent,
    PasswordComponent,
    UserManagementComponent,
    HostManagementComponent,
    ActivityManagementComponent,
    BookingManagementComponent,
    TransactionManagementComponent,
    VoucherManagementComponent,
    PromocodeManagementComponent,
    InvoiceManagementComponent,
    SubAdminManagementComponent,
    AdvertismentManagementComponent,
    EditProfileComponent,
    StaticContentComponent,
    UserManagementDetailComponent,
    HostManagementDetailComponent,
    SubAdminManagementDetailComponent,
    NotificationComponent,
    PushNotificationComponent,
    AddInvoiceComponent,
    AddPromocodeComponent,
    TransactionDetailComponent,
    ActivityDetailComponent,
    AuditLogComponent,
    ReportManagementComponent,
    HostPendingComponent,
    HostRejectedComponent,
    AddSubAdminComponent,
    BookingDetailComponent,
    CategoryComponent,
    AddCategoryComponent,
    CategoryDetailComponent,
    PaymentManagementComponent,
    AddFaqsComponent,
    EditFaqsComponent,
    AllHostProfileComponent,
    AdvertismentDetailComponent,
    PlatformTransactionDetailComponent,
    PromocodeDetailComponent,
    EditpromocodeComponent,
    ComposeNewComponent,
    VoucherDetailComponent,
    EditVoucherComponent,
    AddVoucherComponent,
    InvoiceDetailComponent,
    PushNotificationDetailComponent,
    DefualtManagementComponent,
    ContentReportComponent,
    EditAdminUserComponent,
    CreateSubCategoryComponent,
    ProgrmDetailsComponent,
    FeaturingComponent,
    HostRankComponent,
    FeaturingDetailsComponent,
    FeaturingAddComponent,
    ActivityGroupComponent,
    ActivityGroupDetailsComponent,
    AddActivityGroupComponent,
    EditActivityGroupComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxSliderModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
