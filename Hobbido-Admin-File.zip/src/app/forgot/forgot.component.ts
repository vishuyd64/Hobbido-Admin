import { Component, OnInit } from '@angular/core';
declare var $;

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit {

  

  constructor() { }

  ngOnInit() {
  }

  onModelOpen(){
    $('#myModal').modal('show');
  }

}
