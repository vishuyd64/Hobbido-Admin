import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-host-rejected',
  templateUrl: './host-rejected.component.html',
  styleUrls: ['./host-rejected.component.scss']
})
export class HostRejectedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
