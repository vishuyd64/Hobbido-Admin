import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostRejectedComponent } from './host-rejected.component';

describe('HostRejectedComponent', () => {
  let component: HostRejectedComponent;
  let fixture: ComponentFixture<HostRejectedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostRejectedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostRejectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
