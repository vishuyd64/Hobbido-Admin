import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-voucher',
  templateUrl: './edit-voucher.component.html',
  styleUrls: ['./edit-voucher.component.scss']
})
export class EditVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
