import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-admin-management-detail',
  templateUrl: './sub-admin-management-detail.component.html',
  styleUrls: ['./sub-admin-management-detail.component.scss']
})
export class SubAdminManagementDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
