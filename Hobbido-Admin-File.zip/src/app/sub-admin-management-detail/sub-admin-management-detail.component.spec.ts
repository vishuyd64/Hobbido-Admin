import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubAdminManagementDetailComponent } from './sub-admin-management-detail.component';

describe('SubAdminManagementDetailComponent', () => {
  let component: SubAdminManagementDetailComponent;
  let fixture: ComponentFixture<SubAdminManagementDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubAdminManagementDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubAdminManagementDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
