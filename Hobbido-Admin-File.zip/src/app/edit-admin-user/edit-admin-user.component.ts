import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-admin-user',
  templateUrl: './edit-admin-user.component.html',
  styleUrls: ['./edit-admin-user.component.scss']
})
export class EditAdminUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
