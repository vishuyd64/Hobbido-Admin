import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpromocode',
  templateUrl: './editpromocode.component.html',
  styleUrls: ['./editpromocode.component.scss']
})
export class EditpromocodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
