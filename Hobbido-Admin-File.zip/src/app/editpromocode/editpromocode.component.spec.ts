import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditpromocodeComponent } from './editpromocode.component';

describe('EditpromocodeComponent', () => {
  let component: EditpromocodeComponent;
  let fixture: ComponentFixture<EditpromocodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditpromocodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditpromocodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
