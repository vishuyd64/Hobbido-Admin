import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityGroupDetailsComponent } from './activity-group-details.component';

describe('ActivityGroupDetailsComponent', () => {
  let component: ActivityGroupDetailsComponent;
  let fixture: ComponentFixture<ActivityGroupDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivityGroupDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityGroupDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
