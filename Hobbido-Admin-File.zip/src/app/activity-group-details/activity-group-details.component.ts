import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-group-details',
  templateUrl: './activity-group-details.component.html',
  styleUrls: ['./activity-group-details.component.scss']
})
export class ActivityGroupDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
