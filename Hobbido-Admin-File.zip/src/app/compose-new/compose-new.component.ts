import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-compose-new',
  templateUrl: './compose-new.component.html',
  styleUrls: ['./compose-new.component.scss']
})
export class ComposeNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('.selectAll_checkbox').on('click',function() {
      if($(this).is(':checked')) {
          $(this).parents('li').nextAll('li').find('input').prop('checked',true);
      }else {
          $(this).parents('li').nextAll('li').find('input').prop('checked',false);
      }
  });
  }

}
