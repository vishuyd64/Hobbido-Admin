import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComposeNewComponent } from './compose-new.component';

describe('ComposeNewComponent', () => {
  let component: ComposeNewComponent;
  let fixture: ComponentFixture<ComposeNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComposeNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComposeNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
