import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-activity-group',
  templateUrl: './edit-activity-group.component.html',
  styleUrls: ['./edit-activity-group.component.scss']
})
export class EditActivityGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
