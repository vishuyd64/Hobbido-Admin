import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditActivityGroupComponent } from './edit-activity-group.component';

describe('EditActivityGroupComponent', () => {
  let component: EditActivityGroupComponent;
  let fixture: ComponentFixture<EditActivityGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditActivityGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditActivityGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
