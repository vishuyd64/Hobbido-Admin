import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeaturingAddComponent } from './featuring-add.component';

describe('FeaturingAddComponent', () => {
  let component: FeaturingAddComponent;
  let fixture: ComponentFixture<FeaturingAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeaturingAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeaturingAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
