import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featuring-add',
  templateUrl: './featuring-add.component.html',
  styleUrls: ['./featuring-add.component.scss']
})
export class FeaturingAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
