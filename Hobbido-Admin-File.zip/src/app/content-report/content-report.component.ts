import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-report',
  templateUrl: './content-report.component.html',
  styleUrls: ['./content-report.component.scss']
})
export class ContentReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
