import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-activity-detail',
  templateUrl: './activity-detail.component.html',
  styleUrls: ['./activity-detail.component.scss']
})
export class ActivityDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  //   $(document).ready(function () {
  //     $("#Activity").owlCarousel({
  //         margin: 5,
  //         smartSpeed: 1000,
  //         autoplay: false,
  //         dots: false,
  //         nav: true,
  //         navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
  //         loop: true,
  //         responsive: {
  //             0: {
  //                 items: 1,
  //             },
  //             600: {
  //                 items: 2, 
  //             },
  //             1000: {
  //                 items: 3,
  //             },
  //         },
  //     });
  // });

  $(document).on('click', '.freqBlockShow', function () {
    $('.freqBlockHide').slideDown();
    $('.freqBlockShow').hide();
    $('.freqBlockShow_Less').show();
  });

$(document).on('click','.freqBlockShow_Less', function(){
    $('.freqBlockHide').slideUp();
    $('.freqBlockShow_Less').hide();
    $('.freqBlockShow').show();
})




$(document).ready(function() {
  $('.static_content_menu li a').click(function() {
      var $this = $(this).attr('data-tag');
      $('.static_content_menu li a').parent('li').removeClass('active');
      $(this).parent('li').addClass('active');
      $('.content').hide().removeClass('show');
      $('#' + $this).show();
  });
})
  }

}
