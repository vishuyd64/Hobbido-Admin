import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-host-rank',
  templateUrl: './host-rank.component.html',
  styleUrls: ['./host-rank.component.scss']
})
export class HostRankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
