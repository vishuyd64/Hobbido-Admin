import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostRankComponent } from './host-rank.component';

describe('HostRankComponent', () => {
  let component: HostRankComponent;
  let fixture: ComponentFixture<HostRankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostRankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostRankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
