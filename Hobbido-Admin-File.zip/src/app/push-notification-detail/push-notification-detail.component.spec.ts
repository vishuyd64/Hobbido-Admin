import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PushNotificationDetailComponent } from './push-notification-detail.component';

describe('PushNotificationDetailComponent', () => {
  let component: PushNotificationDetailComponent;
  let fixture: ComponentFixture<PushNotificationDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PushNotificationDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PushNotificationDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
