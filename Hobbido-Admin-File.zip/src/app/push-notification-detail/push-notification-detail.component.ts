import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-push-notification-detail',
  templateUrl: './push-notification-detail.component.html',
  styleUrls: ['./push-notification-detail.component.scss']
})
export class PushNotificationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
