import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-push-notification',
  templateUrl: './push-notification.component.html',
  styleUrls: ['./push-notification.component.scss']
})
export class PushNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('.selectAll_checkbox').on('click',function() {
      if($(this).is(':checked')) {
          $(this).parents('li').nextAll('li').find('input').prop('checked',true);
      }else {
          $(this).parents('li').nextAll('li').find('input').prop('checked',false);
      }
  });
  }

}
