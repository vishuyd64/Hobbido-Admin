import { Component, OnInit } from '@angular/core';
import { Options, LabelType } from "@angular-slider/ngx-slider";

@Component({
  selector: 'app-booking-management',
  templateUrl: './booking-management.component.html',
  styleUrls: ['./booking-management.component.scss']
})
export class BookingManagementComponent implements OnInit {
  minValue: number = 0;
  maxValue: number = 400;
  minValue2: number = 0;
  maxValue2: number = 300;
  options: Options = {
    floor: 0,
    ceil: 500,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return "Min : $" + value;
        case LabelType.High:
          return "Max : $" + value;
        default:
          return "$" + value;
      }
    }
  };

  options2: Options = {
    floor: 0,
    ceil: 500,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return "Min : $" + value;
        case LabelType.High:
          return "Max : $" + value;
        default:
          return "$" + value;
      }
    }
  };

  constructor() { }

  ngOnInit() {
  }

}
