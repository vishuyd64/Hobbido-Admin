import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-voucher',
  templateUrl: './add-voucher.component.html',
  styleUrls: ['./add-voucher.component.scss']
})
export class AddVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
