import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defualt-management',
  templateUrl: './defualt-management.component.html',
  styleUrls: ['./defualt-management.component.scss']
})
export class DefualtManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
