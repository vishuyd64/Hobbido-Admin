import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefualtManagementComponent } from './defualt-management.component';

describe('DefualtManagementComponent', () => {
  let component: DefualtManagementComponent;
  let fixture: ComponentFixture<DefualtManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefualtManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefualtManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
