import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-activity-group',
  templateUrl: './add-activity-group.component.html',
  styleUrls: ['./add-activity-group.component.scss']
})
export class AddActivityGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
