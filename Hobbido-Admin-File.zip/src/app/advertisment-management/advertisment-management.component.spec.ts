import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertismentManagementComponent } from './advertisment-management.component';

describe('AdvertismentManagementComponent', () => {
  let component: AdvertismentManagementComponent;
  let fixture: ComponentFixture<AdvertismentManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvertismentManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvertismentManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
