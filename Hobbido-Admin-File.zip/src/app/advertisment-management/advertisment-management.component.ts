import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertisment-management',
  templateUrl: './advertisment-management.component.html',
  styleUrls: ['./advertisment-management.component.scss']
})
export class AdvertismentManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
