import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-host-management',
  templateUrl: './host-management.component.html',
  styleUrls: ['./host-management.component.scss']
})
export class HostManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function() {

      // block and unblock user
      $('.blockUnblock_btn input').on('change',function() {
          if($(this).is(':checked')) {
              $('#blockModal').modal({show:'false'}); 
          }else {
              $('#unblockModal').modal({show:'false'});
          }
      })
  
      // enable and disable user
      $('.enableDisable_btn input').on('change',function() {
          if($(this).is(':checked')) {
              $('#disableModal').modal({show:'false'}); 
          }else {
              $('#enableModal').modal({show:'false'});
          }
      });
  
  

      $(document).ready(function() {
        $('.static_content_menu li a').click(function() {
            var $this = $(this).attr('data-tag');
            $('.static_content_menu li a').parent('li').removeClass('active');
            $(this).parent('li').addClass('active');
            $('.content').hide().removeClass('show');
            $('#' + $this).show();
        });
    })
  })
  }

}
