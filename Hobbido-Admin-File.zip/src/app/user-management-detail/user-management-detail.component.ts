import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-user-management-detail',
  templateUrl: './user-management-detail.component.html',
  styleUrls: ['./user-management-detail.component.scss']
})
export class UserManagementDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function() {
      $('.static_content_menu li a').click(function() {
          var $this = $(this).attr('data-tag');
          $('.static_content_menu li a').parent('li').removeClass('active');
          $(this).parent('li').addClass('active');
          $('.content').hide().removeClass('show');
          $('#' + $this).show();
      });
  })
  }

}
