import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sub-admin',
  templateUrl: './add-sub-admin.component.html',
  styleUrls: ['./add-sub-admin.component.scss']
})
export class AddSubAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
