import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promocode-management',
  templateUrl: './promocode-management.component.html',
  styleUrls: ['./promocode-management.component.scss']
})
export class PromocodeManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
