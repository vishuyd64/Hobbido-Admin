import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-management',
  templateUrl: './invoice-management.component.html',
  styleUrls: ['./invoice-management.component.scss']
})
export class InvoiceManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
