import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucher-detail',
  templateUrl: './voucher-detail.component.html',
  styleUrls: ['./voucher-detail.component.scss']
})
export class VoucherDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
