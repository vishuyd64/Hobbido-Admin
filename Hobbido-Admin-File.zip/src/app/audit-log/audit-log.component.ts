import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.scss']
})
export class AuditLogComponent implements OnInit {

  colour:Boolean = true 

  constructor() { }

  ngOnInit() {
    $(document).ready(function() {
      $('.static_content_menu li a').click(function() {
          var $this = $(this).attr('data-tag');
          $('.static_content_menu li a').parent('li').removeClass('active');
          $(this).parent('li').addClass('active');
          $('.content').hide().removeClass('show');
          $('#' + $this).show();
      });
  })

    const flag = document.getElementById('flag');
    flag.addEventListener('click', function() {
      flag.classList.toggle('red');
    });

    const flag1 = document.getElementById('flag1');
    flag1.addEventListener('click', function() {
      flag1.classList.toggle('red');
    });

  }

}
