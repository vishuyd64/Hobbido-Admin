import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss']
})
export class AddCategoryComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {

    $(document).on('click', '.Button.ml-2.addsubcat', function () {
      $('.subCat').append("<div class='paddingCom'><span class ='closedd'><i class='fa fa-times'></i></span><div class ='row'><div class ='col-sm-12'><div class='bargainRight'><div class='row'><div class='col-md-4'><div class='form-group'><label>Name in English</label><input type='text'  placeholder='Name in English' class='form-control'></div></div><div class='col-md-4'><div class='form-group'><label>Name in Arabic  </label><input type='text'  placeholder='Name in Arabic '  class='form-control'></div></div><div class='col-md-4'><div class='form-group'><label>Image</label><input type='file' class='form-control'></div></div></div></div></div></div>");
    });
    $(document).on('click','.closedd',function(){
      $(this).parents('.paddingCom').hide();
    });
  }
}
