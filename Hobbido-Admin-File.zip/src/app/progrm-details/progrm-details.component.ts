import { Component, OnInit } from '@angular/core';

declare var $;

@Component({
  selector: 'app-progrm-details',
  templateUrl: './progrm-details.component.html',
  styleUrls: ['./progrm-details.component.scss']
})
export class ProgrmDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function () {
      $("#Activity").owlCarousel({
          margin: 5,
          smartSpeed: 1000,
          autoplay: 3000,
          dots: false,
          nav: true,
          navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
          loop: true,
          responsive: {
              0: {
                  items: 1,
              },
              600: {
                  items: 2, 
              },
              1000: {
                  items: 3,
              },
          },
      });
  });

  $(document).on('click', '.freqBlockShow', function () {
    $('.freqBlockHide').slideDown();
    $('.freqBlockShow').hide();
    $('.freqBlockShow_Less').show();
  });

$(document).on('click','.freqBlockShow_Less', function(){
    $('.freqBlockHide').slideUp();
    $('.freqBlockShow_Less').hide();
    $('.freqBlockShow').show();
})




$(document).ready(function() {
  $('.static_content_menu li a').click(function() {
      var $this = $(this).attr('data-tag');
      $('.static_content_menu li a').parent('li').removeClass('active');
      $(this).parent('li').addClass('active');
      $('.content').hide().removeClass('show');
      $('#' + $this).show();
  });
})
  }

}
