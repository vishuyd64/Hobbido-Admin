import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgrmDetailsComponent } from './progrm-details.component';

describe('ProgrmDetailsComponent', () => {
  let component: ProgrmDetailsComponent;
  let fixture: ComponentFixture<ProgrmDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgrmDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgrmDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
