import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).on('click','.header-notifications',function(){
      $('.NotificationArea-Dropdown').toggle();
    });
  }

}
